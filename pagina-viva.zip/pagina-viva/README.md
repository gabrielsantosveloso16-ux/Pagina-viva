# Página Viva — Catálogo de Livros

Projeto acadêmico de desenvolvimento web para a livraria fictícia **Página Viva**, utilizando HTML5, CSS3 e JavaScript puro.

## 1. Objetivo

O sistema permite cadastrar, consultar, editar e excluir livros de um catálogo. A aplicação foi construída sem frameworks, demonstrando fundamentos de desenvolvimento front-end.

## 2. Tecnologias utilizadas

- HTML5
- CSS3
- JavaScript
- DOM (Document Object Model)
- Flexbox
- CSS Grid
- localStorage
- Caminhos relativos entre arquivos

## 3. Estrutura do projeto

```text
pagina-viva/
├── index.html
├── README.md
├── css/
│   └── style.css
├── js/
│   └── script.js
└── img/
```

A pasta `img` está reservada para imagens adicionais do projeto. As capas também podem ser informadas por URL diretamente no cadastro.

## 4. Como executar

1. Extraia o arquivo ZIP.
2. Abra a pasta `pagina-viva` no Visual Studio Code.
3. Abra o arquivo `index.html`.
4. Execute no navegador.

Também é possível utilizar a extensão **Live Server** do VS Code e clicar em **Open with Live Server**.

Não é necessário instalar Node.js, banco de dados ou qualquer dependência externa.

## 5. Funcionalidades

- Cadastro de livros.
- Validação dos campos obrigatórios.
- Pesquisa por título ou autor.
- Filtro por categoria.
- Exibição dos livros em cards.
- Edição de livros.
- Exclusão de livros com confirmação.
- Contadores de livros, categorias e autores.
- Persistência dos dados com `localStorage`.
- Layout responsivo.
- Modal para edição.
- Mensagens de feedback ao usuário.

## 6. Justificativa do HTML semântico

Foram utilizadas tags semânticas para deixar a estrutura do documento mais organizada e significativa:

- `<header>` representa o cabeçalho da página.
- `<nav>` identifica a área de navegação.
- `<main>` concentra o conteúdo principal.
- `<section>` separa os principais blocos de conteúdo.
- `<article>` representa unidades independentes, como os cards de livros.
- `<aside>` apresenta informações complementares.
- `<footer>` representa o rodapé.
- `<form>` organiza os campos de cadastro.
- `<label>` relaciona os textos aos campos de formulário.

O uso dessas tags facilita a manutenção do código, melhora a organização do documento e contribui para acessibilidade e mecanismos de busca.

## 7. Flexbox e Grid

### Flexbox

O Flexbox foi utilizado em componentes que precisam organizar elementos principalmente em uma direção, como:

- Menu de navegação.
- Botões.
- Ações dos cards.
- Cabeçalho.
- Rodapé.
- Organização de alguns elementos internos.

### CSS Grid

O Grid foi utilizado para estruturas bidimensionais, como:

- Área principal do formulário.
- Cards de estatísticas.
- Catálogo de livros.
- Área "Sobre".
- Organização dos campos em linhas e colunas.

A combinação das duas técnicas permite criar um layout moderno e responsivo.

## 8. Responsividade

O CSS possui media queries para adaptar a interface a diferentes larguras de tela.

Em telas menores:

- O menu pode ocupar múltiplas linhas.
- As colunas do formulário passam para uma coluna.
- O catálogo deixa de utilizar três colunas e passa para uma coluna.
- Os campos são reorganizados verticalmente.
- O conteúdo ocupa melhor o espaço disponível.

Assim, a aplicação pode ser utilizada em computadores, tablets e celulares.

## 9. Manipulação do DOM

O JavaScript utiliza métodos e eventos do DOM para tornar a página interativa.

Exemplos utilizados:

- `document.getElementById()`
- `document.createElement()`
- `addEventListener()`
- `innerHTML`
- `textContent`
- `classList`
- `scrollIntoView()`

O catálogo é renderizado dinamicamente a partir do array de livros.

## 10. localStorage

Os livros cadastrados são armazenados no navegador por meio de:

```javascript
localStorage.setItem()
```

E recuperados com:

```javascript
localStorage.getItem()
```

Isso permite manter os registros após atualizar ou fechar a página, desde que o mesmo navegador e armazenamento do site sejam utilizados.

## 11. Especificidade do CSS

A especificidade determina qual regra CSS possui prioridade quando mais de uma regra pode afetar o mesmo elemento.

Neste projeto foram utilizados principalmente:

- Seletores de elementos, como `body`, `button` e `h2`.
- Classes, como `.button`, `.book-card` e `.container`.
- Classes combinadas e seletores de estado, como `.button.primary` e `.button:hover`.
- Identificadores foram utilizados principalmente no JavaScript para localizar elementos, evitando depender deles para toda a estilização.

A organização procura manter as regras simples e previsíveis, reduzindo conflitos entre estilos.

## 12. Caminhos relativos

O arquivo `index.html` utiliza caminhos relativos:

```html
<link rel="stylesheet" href="css/style.css">
<script src="js/script.js"></script>
```

Isso significa que o navegador procura o CSS dentro da pasta `css` e o JavaScript dentro da pasta `js`, considerando a localização do arquivo HTML como referência.

Essa organização facilita a portabilidade do projeto e permite compactar toda a aplicação sem depender de caminhos absolutos do computador.

## 13. Validação

O cadastro verifica:

- Título preenchido.
- Autor preenchido.
- Categoria selecionada.
- Preço maior que zero.
- Quantidade inteira igual ou maior que zero.

A validação acontece antes de inserir o livro no catálogo.

## 14. Conclusão

O projeto Página Viva demonstra a integração de HTML, CSS e JavaScript em uma aplicação front-end funcional. A utilização de HTML semântico, Flexbox, CSS Grid, responsividade, manipulação do DOM e localStorage atende aos principais objetivos técnicos da atividade e demonstra a aplicação prática dos conceitos estudados.

---

**Projeto:** Página Viva  
**Tipo:** Aplicação Web Front-end  
**Tecnologias:** HTML5 + CSS3 + JavaScript

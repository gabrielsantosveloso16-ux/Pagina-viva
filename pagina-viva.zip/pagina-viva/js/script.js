const STORAGE_KEY = "paginaVivaLivros";

const livroForm = document.getElementById("livroForm");
const catalogoGrid = document.getElementById("catalogoGrid");
const estadoVazio = document.getElementById("estadoVazio");
const busca = document.getElementById("busca");
const filtroCategoria = document.getElementById("filtroCategoria");
const formFeedback = document.getElementById("formFeedback");

const modalOverlay = document.getElementById("modalOverlay");
const fecharModal = document.getElementById("fecharModal");
const editarForm = document.getElementById("editarForm");

let livros = carregarLivros();

document.getElementById("anoAtual").textContent = new Date().getFullYear();

function carregarLivros() {
    try {
        const dados = localStorage.getItem(STORAGE_KEY);
        if (dados) {
            return JSON.parse(dados);
        }
    } catch (erro) {
        console.error("Erro ao carregar livros:", erro);
    }

    return [
        {
            id: gerarId(),
            titulo: "O Pequeno Príncipe",
            autor: "Antoine de Saint-Exupéry",
            categoria: "Infantil",
            preco: 39.90,
            quantidade: 8,
            capa: ""
        },
        {
            id: gerarId(),
            titulo: "Dom Casmurro",
            autor: "Machado de Assis",
            categoria: "Romance",
            preco: 29.90,
            quantidade: 12,
            capa: ""
        },
        {
            id: gerarId(),
            titulo: "O Hobbit",
            autor: "J. R. R. Tolkien",
            categoria: "Fantasia",
            preco: 49.90,
            quantidade: 5,
            capa: ""
        }
    ];
}

function salvarLivros() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(livros));
}

function gerarId() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2);
}

function escaparHTML(valor) {
    return String(valor)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function formatarPreco(valor) {
    return Number(valor).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });
}

function validarLivro(dados, prefixo = "") {
    let valido = true;

    const titulo = dados.titulo.trim();
    const autor = dados.autor.trim();
    const categoria = dados.categoria;
    const preco = Number(dados.preco);
    const quantidade = Number(dados.quantidade);

    if (!titulo) {
        mostrarErro(`${prefixo}tituloError`, "Informe o título.");
        valido = false;
    } else {
        limparErro(`${prefixo}tituloError`);
    }

    if (!autor) {
        mostrarErro(`${prefixo}autorError`, "Informe o autor.");
        valido = false;
    } else {
        limparErro(`${prefixo}autorError`);
    }

    if (!categoria) {
        mostrarErro(`${prefixo}categoriaError`, "Selecione uma categoria.");
        valido = false;
    } else {
        limparErro(`${prefixo}categoriaError`);
    }

    if (!Number.isFinite(preco) || preco <= 0) {
        mostrarErro(`${prefixo}precoError`, "Informe um preço maior que zero.");
        valido = false;
    } else {
        limparErro(`${prefixo}precoError`);
    }

    if (!Number.isInteger(quantidade) || quantidade < 0) {
        mostrarErro(`${prefixo}quantidadeError`, "Informe uma quantidade válida.");
        valido = false;
    } else {
        limparErro(`${prefixo}quantidadeError`);
    }

    return valido;
}

function mostrarErro(id, mensagem) {
    const elemento = document.getElementById(id);
    if (elemento) {
        elemento.textContent = mensagem;
    }
}

function limparErro(id) {
    const elemento = document.getElementById(id);
    if (elemento) {
        elemento.textContent = "";
    }
}

livroForm.addEventListener("submit", function(evento) {
    evento.preventDefault();

    const dados = {
        titulo: document.getElementById("titulo").value,
        autor: document.getElementById("autor").value,
        categoria: document.getElementById("categoria").value,
        preco: document.getElementById("preco").value,
        quantidade: document.getElementById("quantidade").value,
        capa: document.getElementById("capa").value.trim()
    };

    if (!validarLivro(dados)) {
        mostrarFeedback("Corrija os campos indicados.", "error");
        return;
    }

    const novoLivro = {
        id: gerarId(),
        titulo: dados.titulo.trim(),
        autor: dados.autor.trim(),
        categoria: dados.categoria,
        preco: Number(dados.preco),
        quantidade: Number(dados.quantidade),
        capa: dados.capa
    };

    livros.push(novoLivro);
    salvarLivros();
    atualizarInterface();

    livroForm.reset();
    mostrarFeedback("Livro cadastrado com sucesso!", "success");

    document.getElementById("catalogo").scrollIntoView({
        behavior: "smooth",
        block: "start"
    });
});

document.getElementById("limparForm").addEventListener("click", function() {
    limparTodosErros();
    mostrarFeedback("", "");
});

function mostrarFeedback(mensagem, tipo) {
    formFeedback.textContent = mensagem;
    formFeedback.className = "form-feedback";

    if (tipo) {
        formFeedback.classList.add(tipo);
    }
}

function limparTodosErros() {
    ["tituloError", "autorError", "categoriaError", "precoError", "quantidadeError"].forEach(limparErro);
}

function atualizarInterface() {
    atualizarFiltros();
    renderizarCatalogo();
    atualizarEstatisticas();
}

function atualizarFiltros() {
    const valorAtual = filtroCategoria.value;
    const categorias = [...new Set(livros.map(livro => livro.categoria))].sort((a, b) => a.localeCompare(b));

    filtroCategoria.innerHTML = '<option value="">Todas</option>';

    categorias.forEach(categoria => {
        const option = document.createElement("option");
        option.value = categoria;
        option.textContent = categoria;
        filtroCategoria.appendChild(option);
    });

    if (categorias.includes(valorAtual)) {
        filtroCategoria.value = valorAtual;
    }
}

function obterLivrosFiltrados() {
    const termo = busca.value.trim().toLowerCase();
    const categoria = filtroCategoria.value;

    return livros.filter(livro => {
        const correspondeBusca =
            livro.titulo.toLowerCase().includes(termo) ||
            livro.autor.toLowerCase().includes(termo);

        const correspondeCategoria =
            !categoria || livro.categoria === categoria;

        return correspondeBusca && correspondeCategoria;
    });
}

function renderizarCatalogo() {
    const lista = obterLivrosFiltrados();
    catalogoGrid.innerHTML = "";

    estadoVazio.classList.toggle("visible", lista.length === 0);

    lista.forEach(livro => {
        const card = document.createElement("article");
        card.className = "book-card";

        const capaHTML = livro.capa
            ? `<img class="book-cover" src="${escaparHTML(livro.capa)}" alt="Capa do livro ${escaparHTML(livro.titulo)}" onerror="this.style.display='none'; this.nextElementSibling.style.display='grid';">
               <div class="book-cover-placeholder" style="display:none;">📖</div>`
            : `<div class="book-cover-placeholder">📖</div>`;

        card.innerHTML = `
            ${capaHTML}
            <div class="book-info">
                <span class="book-category">${escaparHTML(livro.categoria)}</span>
                <h3 class="book-title">${escaparHTML(livro.titulo)}</h3>
                <p class="book-author">por ${escaparHTML(livro.autor)}</p>
                <div class="book-meta">
                    <span class="book-price">${formatarPreco(livro.preco)}</span>
                    <span class="book-stock">${livro.quantidade} em estoque</span>
                </div>
                <div class="card-actions">
                    <button class="card-button" data-action="editar" data-id="${livro.id}">Editar</button>
                    <button class="card-button delete" data-action="excluir" data-id="${livro.id}">Excluir</button>
                </div>
            </div>
        `;

        catalogoGrid.appendChild(card);
    });
}

catalogoGrid.addEventListener("click", function(evento) {
    const botao = evento.target.closest("[data-action]");
    if (!botao) return;

    const id = botao.dataset.id;
    const acao = botao.dataset.action;

    if (acao === "editar") {
        abrirEdicao(id);
    }

    if (acao === "excluir") {
        excluirLivro(id);
    }
});

function excluirLivro(id) {
    const livro = livros.find(item => item.id === id);
    if (!livro) return;

    const confirmar = window.confirm(`Deseja realmente excluir "${livro.titulo}"?`);

    if (!confirmar) return;

    livros = livros.filter(item => item.id !== id);
    salvarLivros();
    atualizarInterface();
}

function abrirEdicao(id) {
    const livro = livros.find(item => item.id === id);
    if (!livro) return;

    document.getElementById("editarId").value = livro.id;
    document.getElementById("editarTitulo").value = livro.titulo;
    document.getElementById("editarAutor").value = livro.autor;
    document.getElementById("editarCategoria").value = livro.categoria;
    document.getElementById("editarPreco").value = livro.preco;
    document.getElementById("editarQuantidade").value = livro.quantidade;
    document.getElementById("editarCapa").value = livro.capa || "";

    modalOverlay.classList.add("open");
    modalOverlay.setAttribute("aria-hidden", "false");
    document.getElementById("editarTitulo").focus();
}

function fecharJanelaEdicao() {
    modalOverlay.classList.remove("open");
    modalOverlay.setAttribute("aria-hidden", "true");
}

fecharModal.addEventListener("click", fecharJanelaEdicao);

modalOverlay.addEventListener("click", function(evento) {
    if (evento.target === modalOverlay) {
        fecharJanelaEdicao();
    }
});

document.addEventListener("keydown", function(evento) {
    if (evento.key === "Escape" && modalOverlay.classList.contains("open")) {
        fecharJanelaEdicao();
    }
});

editarForm.addEventListener("submit", function(evento) {
    evento.preventDefault();

    const id = document.getElementById("editarId").value;
    const indice = livros.findIndex(item => item.id === id);

    if (indice === -1) return;

    const titulo = document.getElementById("editarTitulo").value.trim();
    const autor = document.getElementById("editarAutor").value.trim();
    const categoria = document.getElementById("editarCategoria").value;
    const preco = Number(document.getElementById("editarPreco").value);
    const quantidade = Number(document.getElementById("editarQuantidade").value);
    const capa = document.getElementById("editarCapa").value.trim();

    if (!titulo || !autor || !categoria || !Number.isFinite(preco) || preco <= 0 || !Number.isInteger(quantidade) || quantidade < 0) {
        alert("Preencha corretamente todos os campos obrigatórios.");
        return;
    }

    livros[indice] = {
        ...livros[indice],
        titulo,
        autor,
        categoria,
        preco,
        quantidade,
        capa
    };

    salvarLivros();
    atualizarInterface();
    fecharJanelaEdicao();
});

busca.addEventListener("input", renderizarCatalogo);
filtroCategoria.addEventListener("change", renderizarCatalogo);

function atualizarEstatisticas() {
    document.getElementById("totalLivros").textContent = livros.length;

    const categorias = new Set(livros.map(livro => livro.categoria));
    const autores = new Set(livros.map(livro => livro.autor.toLowerCase()));

    document.getElementById("totalCategorias").textContent = categorias.size;
    document.getElementById("totalAutores").textContent = autores.size;
}

atualizarInterface();
